package com.example.pooloverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 701
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(0xFF101419.toInt())
        }
        val title = TextView(this).apply {
            text = "Pool Overlay — прототип"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
        }
        info = TextView(this).apply {
            text = "Этот первый этап проверяет разрешения захвата экрана и отображение тестовой линии поверх игры. Автоматическое распознавание шаров пока не реализовано."
            textSize = 16f
            setTextColor(0xFFD2DCE3.toInt())
            setPadding(0, 20, 0, 20)
        }
        val overlay = makeButton("1. Разрешить отображение поверх других приложений") {
            if (!Settings.canDrawOverlays(this)) {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(i)
            } else toast("Разрешение уже включено")
        }
        val start = makeButton("2. Запустить тестовую линию") {
            if (!Settings.canDrawOverlays(this)) {
                toast("Сначала включи разрешение отображения поверх приложений")
                return@makeButton
            }
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
        }
        val stop = makeButton("Остановить оверлей") {
            stopService(Intent(this, CaptureOverlayService::class.java))
            toast("Оверлей остановлен")
        }
        root.addView(title, lp())
        root.addView(info, lp())
        root.addView(overlay, lp())
        root.addView(start, lp())
        root.addView(stop, lp())
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = 12
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureOverlayService::class.java).apply {
                putExtra(CaptureOverlayService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureOverlayService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
            info.text = "Запущен прототип. Переключись в 8 Ball Pool: должна появиться тестовая зелёная линия. Это пока не анализирует шары автоматически."
        } else if (requestCode == captureRequest) toast("Захват экрана отменён")
    }
}
